/**
 * Utility functions for generating short memorial URLs and sharing via WhatsApp / Clipboard.
 */

import { Deceased } from '../types';

export const PUBLIC_PRODUCTION_URL = 'https://peaceful-tarsier-9f8a3d.netlify.app';

/**
 * Encodes a Deceased object into a URL-safe Base64URL string.
 * Base64URL uses ONLY alphanumeric characters, hyphens and underscores (a-z, A-Z, 0-9, -, _).
 * It contains NO '%', NO '{', NO '"', NO spaces or special symbols, guaranteeing that WhatsApp,
 * Telegram, SMS, and email clients format it as a 100% clickable hyperlink without truncation!
 */
export function encodeDeceasedToUrlPayload(deceased: Deceased): string {
  try {
    const compactObj = {
      i: deceased.id,
      n: deceased.name,
      g: deceased.gender,
      fn: deceased.fatherName || '',
      mn: deceased.motherName || '',
      d: deceased.day,
      m: deceased.month,
      p: deceased.contactPhone || '',
      nt: deceased.notes || '',
      a: deceased.ageAtDeath,
      bd: deceased.birthDate || ''
    };
    const jsonStr = JSON.stringify(compactObj);
    
    // UTF-8 byte encoding
    const encoder = new TextEncoder();
    const bytes = encoder.encode(jsonStr);
    let binString = "";
    for (let i = 0; i < bytes.length; i++) {
      binString += String.fromCharCode(bytes[i]);
    }
    const b64 = btoa(binString);
    
    // Convert to URL-Safe Base64 (replace + with -, / with _, remove = padding)
    return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  } catch (e) {
    console.error("Error encoding deceased payload:", e);
    return '';
  }
}

/**
 * Decodes a URL parameter string back into a Deceased object.
 * Supports Base64URL, URL-encoded JSON, raw JSON, and legacy Base64 formats.
 */
export function decodeDeceasedFromUrlPayload(encodedStr: string): Deceased | null {
  if (!encodedStr) return null;

  const parseDeceasedObject = (parsed: any): Deceased | null => {
    if (parsed && (parsed.i || parsed.id) && (parsed.n || parsed.name)) {
      return {
        id: Number(parsed.i || parsed.id),
        name: String(parsed.n || parsed.name),
        gender: (parsed.g || parsed.gender) === 'female' ? 'female' : 'male',
        fatherName: String(parsed.fn || parsed.fatherName || ''),
        motherName: String(parsed.mn || parsed.motherName || ''),
        day: Number(parsed.d || parsed.day),
        month: String(parsed.m || parsed.month),
        contactPhone: String(parsed.p || parsed.contactPhone || ''),
        notes: String(parsed.nt || parsed.notes || ''),
        ageAtDeath: parsed.a !== undefined ? Number(parsed.a) : (parsed.ageAtDeath !== undefined ? Number(parsed.ageAtDeath) : undefined),
        birthDate: parsed.bd ? String(parsed.bd) : (parsed.birthDate ? String(parsed.birthDate) : undefined)
      };
    }
    return null;
  };

  // Attempt 1: Base64URL decode (standard modern format)
  try {
    let b64 = encodedStr.replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4 !== 0) {
      b64 += '=';
    }
    const binString = atob(b64);
    const bytes = Uint8Array.from(binString, (m) => m.codePointAt(0)!);
    const jsonStr = new TextDecoder().decode(bytes);
    const parsed = JSON.parse(jsonStr);
    const res = parseDeceasedObject(parsed);
    if (res) return res;
  } catch (e) {
    // Continue
  }

  // Attempt 2: Legacy encodeURIComponent JSON decode
  try {
    let jsonStr = encodedStr;
    if (encodedStr.includes('%')) {
      jsonStr = decodeURIComponent(encodedStr);
    }
    const parsed = JSON.parse(jsonStr);
    const res = parseDeceasedObject(parsed);
    if (res) return res;
  } catch (e) {
    // Continue
  }

  // Attempt 3: Legacy Base64 decode with '+' restoration
  try {
    const normalizedB64 = encodedStr.replace(/ /g, '+');
    const jsonStr = decodeURIComponent(
      Array.prototype.map.call(atob(normalizedB64), (c: string) => 
        '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
      ).join('')
    );
    const parsed = JSON.parse(jsonStr);
    const res = parseDeceasedObject(parsed);
    if (res) return res;
  } catch (e) {
    // Continue
  }

  return null;
}

/**
 * Generates a full memorial link.
 * If a Deceased object is provided, encodes its payload directly into `data` query param so that
 * ANY user opening this link anywhere in the world (e.g. Netlify, mobile phones, WhatsApp)
 * will immediately see the complete memorial page without needing a server database or prior local storage!
 */
export function getShortMemorialUrl(deceasedOrId: number | Deceased, lang?: string): string {
  const langSuffix = (lang && lang !== 'he') ? `&lang=${lang}` : '';
  let id: number;
  let dataParam = '';

  if (typeof deceasedOrId === 'object' && deceasedOrId !== null) {
    id = deceasedOrId.id;
    const payload = encodeDeceasedToUrlPayload(deceasedOrId);
    if (payload) {
      dataParam = `&data=${payload}`;
    }
  } else {
    id = Number(deceasedOrId);
  }

  let baseOrigin = window.location.origin;

  // If running in local/file environment or AI Studio sandbox environment, always use the public Netlify production URL
  if (
    !baseOrigin ||
    window.location.protocol === 'file:' ||
    baseOrigin === 'null' ||
    baseOrigin.includes('ais-dev-') ||
    baseOrigin.includes('ais-pre-')
  ) {
    baseOrigin = PUBLIC_PRODUCTION_URL;
  }

  return `${baseOrigin}/?d=${id}${dataParam}${langSuffix}`;
}

export function openWhatsAppShare(text: string) {
  // Universal WhatsApp web/app link that works across all mobile OS (Android, iOS), desktop browsers, and WhatsApp Web
  const encodedText = encodeURIComponent(text);
  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
  
  try {
    const win = window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    if (!win || win.closed || typeof win.closed === 'undefined') {
      window.location.href = `https://wa.me/?text=${encodedText}`;
    }
  } catch (e) {
    window.location.href = `https://wa.me/?text=${encodedText}`;
  }
}


