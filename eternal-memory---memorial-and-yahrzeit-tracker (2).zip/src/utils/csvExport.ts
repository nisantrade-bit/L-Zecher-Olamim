/**
 * Utility for exporting memorial database records to CSV format in Hebrew, English, and Russian.
 */

import { Deceased, Language } from '../types';
import { translateDeceasedListClientSide } from './transliteration';

/**
 * Escapes a cell value for safe CSV output
 */
function escapeCsvCell(cell: string | number | undefined): string {
  if (cell === undefined || cell === null) return '""';
  const str = String(cell).replace(/"/g, '""');
  return `"${str}"`;
}

/**
 * Exports a single language CSV file
 */
export function exportSingleLanguageCsv(deceasedList: Deceased[], lang: Language, filename?: string) {
  if (!deceasedList || deceasedList.length === 0) return;

  // Ensure list is cleanly translated into target language
  const translatedList = translateDeceasedListClientSide(deceasedList, lang);

  const headers = lang === 'he' ? [
    'שם מלא',
    'מין (male/female)',
    'שם האב/הורה',
    'שם האם',
    'יום עברי (1-30)',
    'חודש עברי',
    'טלפון קשר',
    'סיפור חיים והערות'
  ] : lang === 'ru' ? [
    'Полное имя',
    'Пол (male/female)',
    'Имя отца/родителя',
    'Имя матери',
    'Еврейский день (1-30)',
    'Еврейский месяц',
    'Телефон',
    'Примечания'
  ] : [
    'Full Name',
    'Gender (male/female)',
    'Father Name',
    'Mother Name',
    'Hebrew Day (1-30)',
    'Hebrew Month',
    'Contact Phone',
    'Life Story'
  ];

  const rows: string[] = [];
  rows.push(headers.map(h => escapeCsvCell(h)).join(','));

  translatedList.forEach(item => {
    const row = [
      escapeCsvCell(item.name),
      escapeCsvCell(item.gender),
      escapeCsvCell(item.fatherName || ''),
      escapeCsvCell(item.motherName || ''),
      escapeCsvCell(item.day),
      escapeCsvCell(item.month),
      escapeCsvCell(item.contactPhone || ''),
      escapeCsvCell(item.notes || '')
    ];
    rows.push(row.join(','));
  });

  // UTF-8 BOM (\uFEFF) ensures Excel/software opens Hebrew and Russian text correctly
  const csvContent = '\uFEFF' + rows.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.setAttribute('href', url);
  const defaultFileName = filename || (
    lang === 'he' 
      ? `רשימת_נפטרים_עברית.csv` 
      : lang === 'ru' 
      ? `список_усопших_русский.csv` 
      : `memorial_list_english.csv`
  );

  link.setAttribute('download', defaultFileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Downloads the deceased list as CSV files for all 3 languages (Hebrew, English, Russian)
 */
export function downloadDeceasedCsv(deceasedList: Deceased[], _activeLang?: Language) {
  if (!deceasedList || deceasedList.length === 0) return;

  const languages: { code: Language; filename: string }[] = [
    { code: 'he', filename: 'רשימת_נפטרים_עברית.csv' },
    { code: 'en', filename: 'memorial_list_english.csv' },
    { code: 'ru', filename: 'список_усопших_русский.csv' }
  ];

  languages.forEach((langObj, idx) => {
    setTimeout(() => {
      exportSingleLanguageCsv(deceasedList, langObj.code, langObj.filename);
    }, idx * 250);
  });
}

