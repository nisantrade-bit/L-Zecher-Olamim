/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Deceased, Language } from '../types';
import { translations, formatParentRelation } from '../utils/translations';
import { translateText } from '../utils/transliteration';
import { getHebrewDate, isYahrzeitMatch, HEBREW_MONTHS_HE, HEBREW_MONTHS_EN, HEBREW_MONTHS_RU, gimatriya, normalizeMonthName, getYahrzeitEveDate } from '../utils/hebrewDate';
import { Bell, Heart, Share2, BookOpen, Calendar, MessageCircle, Info, MapPin } from 'lucide-react';
import { getTorahPortionDetails } from '../utils/torahPortionHelper';
import { getShortMemorialUrl, openWhatsAppShare } from '../utils/shareUtils';

const CITIES = [
  { id: 293397, nameHe: "תל אביב", nameEn: "Tel Aviv", nameRu: "Тель-Авив" },
  { id: 281184, nameHe: "ירושלים", nameEn: "Jerusalem", nameRu: "Иерусалим" },
  { id: 294801, nameHe: "חיפה", nameEn: "Haifa", nameRu: "Хайфа" },
  { id: 5128581, nameHe: "ניו יורק", nameEn: "New York", nameRu: "Нью-Йорк" },
  { id: 2643743, nameHe: "לונדון", nameEn: "London", nameRu: "Лондон" },
  { id: 2988507, nameHe: "פריז", nameEn: "Paris", nameRu: "Париж" },
  { id: 524901, nameHe: "מוסקבה", nameEn: "Moscow", nameRu: "Москва" },
  { id: 703448, nameHe: "קייב", nameEn: "Киев", nameRu: "Киев" }
];

interface BulletinBoardProps {
  deceasedList: Deceased[];
  lang: Language;
  onSelectDeceased: (deceased: Deceased) => void;
}

export const BulletinBoard: React.FC<BulletinBoardProps> = ({ deceasedList, lang, onSelectDeceased }) => {
  const t = translations[lang];

  const [hebcalEvents, setHebcalEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const [selectedCity, setSelectedCity] = useState(() => {
    try {
      const stored = localStorage.getItem('shabbat_default_city_id');
      if (stored) {
        const found = CITIES.find(c => c.id === Number(stored));
        if (found) return found;
      }
    } catch (e) {}
    return CITIES[0]; // Tel Aviv
  });

  const [shabbatCandles, setShabbatCandles] = useState<string>('');
  const [shabbatHavdalah, setShabbatHavdalah] = useState<string>('');

  // Periodically check if city has been changed in localStorage elsewhere (e.g. Calendar tab)
  useEffect(() => {
    const checkCity = () => {
      try {
        const stored = localStorage.getItem('shabbat_default_city_id');
        if (stored) {
          const found = CITIES.find(c => c.id === Number(stored));
          if (found && found.id !== selectedCity.id) {
            setSelectedCity(found);
          }
        }
      } catch (e) {}
    };
    const interval = setInterval(checkCity, 1000);
    return () => clearInterval(interval);
  }, [selectedCity.id]);

  // Fetch current week's Shabbat times
  useEffect(() => {
    const fetchCurrentShabbatTimes = async () => {
      try {
        const res = await fetch(`https://www.hebcal.com/shabbat?cfg=json&geonameid=${selectedCity.id}&m=50&b=18`);
        if (res.ok) {
          const data = await res.json();
          const candleItem = data.items?.find((item: any) => item.category === "candles");
          const havdalahItem = data.items?.find((item: any) => item.category === "havdalah");
          
          if (candleItem) {
            setShabbatCandles(candleItem.title.split(": ")[1] || candleItem.title);
          } else {
            setShabbatCandles('');
          }

          if (havdalahItem) {
            setShabbatHavdalah(havdalahItem.title.split(": ")[1] || havdalahItem.title);
          } else {
            setShabbatHavdalah('');
          }
        }
      } catch (err) {
        console.error("Error fetching current Shabbat times:", err);
      }
    };

    fetchCurrentShabbatTimes();
  }, [selectedCity.id]);

  // Fetch all annual events on load to compute preceding Shabbats and weekly portions
  useEffect(() => {
    const fetchYearEvents = async () => {
      setLoading(true);
      try {
        const year = new Date().getFullYear();
        // Since we are primarily showing in Israel context on default board, fetch both/israel custom.
        // We will default to Israel custom (i=on) or we can match user's custom if chosen.
        const response = await fetch(`https://www.hebcal.com/hebcal?v=1&cfg=json&s=on&maj=on&min=on&mod=on&nh=on&year=${year}&i=on`);
        if (response.ok) {
          const data = await response.json();
          setHebcalEvents(data.items || []);
        }
      } catch (err) {
        console.error("Error fetching Hebcal for Bulletin Board:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchYearEvents();
  }, []);

  // Helper to compute preceding Shabbat's parasha for a given Yahrzeit date
  const getPrecedingShabbatParasha = (gregDate: Date) => {
    const dayOfWeek = gregDate.getDay();
    const prevSat = new Date(gregDate);
    const daysToSubtract = dayOfWeek === 6 ? 7 : dayOfWeek + 1;
    prevSat.setDate(prevSat.getDate() - daysToSubtract);
    
    const yyyy = prevSat.getFullYear();
    const mm = String(prevSat.getMonth() + 1).padStart(2, '0');
    const dd = String(prevSat.getDate()).padStart(2, '0');
    const prevSatStr = `${yyyy}-${mm}-${dd}`;

    const parashaItem = hebcalEvents.find(
      (item) => item.category === 'parashat' && item.date === prevSatStr
    );

    if (parashaItem) {
      return {
        title: parashaItem.title,
        hebrew: parashaItem.hebrew || parashaItem.title
      };
    }

    // Check if there is a special holiday on that day
    const holidayItem = hebcalEvents.find(
      (item) => item.category === 'holiday' && item.date === prevSatStr
    );
    if (holidayItem) {
      return {
        title: holidayItem.title,
        hebrew: holidayItem.hebrew || holidayItem.title
      };
    }

    return null;
  };

  // Compute Saturday of the current week for weekly bulletin
  const today = new Date();
  const dayOfWeek = today.getDay();
  const satOfThisWeek = new Date(today);
  satOfThisWeek.setDate(today.getDate() + (6 - dayOfWeek));
  const satOfThisWeekStr = `${satOfThisWeek.getFullYear()}-${String(satOfThisWeek.getMonth() + 1).padStart(2, '0')}-${String(satOfThisWeek.getDate()).padStart(2, '0')}`;

  const currentParashaItem = hebcalEvents.find(
    (item) => item.category === 'parashat' && item.date === satOfThisWeekStr
  );

  // Find holidays in the current week (from Sunday to Saturday)
  const sunOfThisWeek = new Date(today);
  sunOfThisWeek.setDate(today.getDate() - dayOfWeek);
  
  const currentWeekHolidays = hebcalEvents.filter((item) => {
    if (item.category !== 'holiday') return false;
    const itemDate = new Date(item.date);
    return itemDate >= sunOfThisWeek && itemDate <= satOfThisWeek;
  });

  // Generate date array for the next 7 days (including today)
  const daysArray = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });

  const matchedEvents: Array<{
    deceased: Deceased;
    daysCount: number; // 0 = today, 1 = tomorrow, 2..6 = in N days
    gregorianDate: Date;
    hebrewDateStr: string;
  }> = [];

  daysArray.forEach((date, index) => {
    const hb = getHebrewDate(date);
    
    // Find matching deceased
    deceasedList.forEach(deceased => {
      if (isYahrzeitMatch(deceased.day, deceased.month, hb.day, hb.normalizedMonth, hb.isLeapYear)) {
        // Get month name in active language
        let monthIdx = HEBREW_MONTHS_HE.indexOf(hb.normalizedMonth);
        if (monthIdx === -1) monthIdx = 0;
        const localizedMonth = lang === 'he' ? HEBREW_MONTHS_HE[monthIdx] : lang === 'en' ? HEBREW_MONTHS_EN[monthIdx] : HEBREW_MONTHS_RU[monthIdx];
        const localizedDay = lang === 'he' ? gimatriya(hb.day) : hb.day.toString();
        
        matchedEvents.push({
          deceased,
          daysCount: index,
          gregorianDate: date,
          hebrewDateStr: lang === 'he' ? `${localizedDay} ב${localizedMonth}` : `${localizedDay} ${localizedMonth}`
        });
      }
    });
  });

  const todayList = matchedEvents.filter(e => e.daysCount === 0);
  const upcomingList = matchedEvents.filter(e => e.daysCount > 0);

  // Formulates the halachic text based on language and gender
  const formatHalachicAlert = (deceased: Deceased, day: string, month: string) => {
    const parentRel = formatParentRelation(deceased.gender, deceased.fatherName, deceased.motherName, lang);
    const translatedName = lang === 'he' ? deceased.name : translateText(deceased.name, lang as 'en' | 'ru');

    if (lang === 'he') {
      return `אזכרה של ${translatedName} ${parentRel} בתאריך ${day} ב${month}.`;
    } else if (lang === 'ru') {
      return `Йарцайт: ${translatedName} ${parentRel}, дата ${day} ${month}.`;
    } else {
      return `Yahrzeit of ${translatedName} ${parentRel} on ${day} of ${month}.`;
    }
  };

  // Triggers the WhatsApp share invitation
  const shareOnWhatsApp = (deceased: Deceased, gregDate: Date, hebrewDateStr: string, parashaName: string | null, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent opening details modal
    
    const parentRelation = formatParentRelation(deceased.gender, deceased.fatherName, deceased.motherName, lang);
    const shortUrl = getShortMemorialUrl(deceased, lang);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(gregDate);
    target.setHours(0, 0, 0, 0);
    const diffTime = target.getTime() - today.getTime();
    const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    let text = "";
    if (lang === 'he') {
      text = `🕯️ *אזכרה וזיכרון לעילוי נשמה - לזכר עולמים* 🕯️\n\n`;
      text += `הננו להודיע על התקרבות האזכרה השנתית (יארצייט) של יקירנו:\n`;
      text += `*${deceased.name}* - *${parentRelation}*\n\n`;
      const eveDate = getYahrzeitEveDate(gregDate);
      const eveDayName = eveDate.toLocaleDateString('he-IL', { weekday: 'long' });
      const eveDateStr = eveDate.toLocaleDateString('he-IL');

      text += `📅 *תאריך עברי:* ${hebrewDateStr}\n`;
      text += `🕯️ *תחילת האזכרה והדלקת נר נשמה (ערב האזכרה):* ${eveDayName} בערב, ${eveDateStr} (בשקיעה)\n`;
      text += `📅 *יום האזכרה בלועזי:* ${gregDate.toLocaleDateString('he-IL')}\n`;
      if (parashaName) {
        text += `📖 *שבת עליה לתורה / אזכרה:* שבת פרשת ${parashaName}\n`;
      }
      if (daysRemaining === 0) {
        text += `📢 *האזכרה השנתית מתקיימת היום!*\n`;
      } else if (daysRemaining === 1) {
        text += `📢 *מחר האזכרה השנתית (נשאר יום אחד)*\n`;
      } else {
        text += `📢 *נשארו עוד ${daysRemaining} ימים לאזכרה השנתית*\n`;
      }
      text += `\n🔗 לצפייה במודעת הזיכרון, הדלקת נר נשמה ולימוד לעילוי נשמתו/ה:\n`;
      text += `${shortUrl}\n\n`;
      text += `_יהי זכרו/ה ברוך ומנוחתו/ה בגן עדן_ 🙏`;
    } else if (lang === 'ru') {
      text = `🕯️ *День памяти (Йарцайт) - Лезэхер Оламим* 🕯️\n\n`;
      text += `Сообщаем о приближении годовщины памяти нашего дорогого человека:\n`;
      text += `*${deceased.name}* - *${parentRelation}*\n\n`;
      text += `📅 *Еврейская дата:* ${hebrewDateStr}\n`;
      text += `📅 *Григорианская дата:* ${gregDate.toLocaleDateString('ru-RU')}\n`;
      if (parashaName) {
        text += `📖 *Недельная глава Торы (Шаббат):* ${parashaName}\n`;
      }
      if (daysRemaining === 0) {
        text += `📢 *Йорцайт проходит сегодня!*\n`;
      } else if (daysRemaining === 1) {
        text += `📢 *Йорцайт состоится завтра (остался 1 день)*\n`;
      } else {
        text += `📢 *Осталось ${daysRemaining} дней до годовщины поминовения (Йорцайта)*\n`;
      }
      text += `\nВ память об усопшем приглашаем вас зажечь виртуальную свечу, оставить слова памяти и прочесть Тегилим:\n`;
      text += `🔗 ${shortUrl}\n\n`;
      text += `_Пусть душа его/ее пребывает в мире и покое_ 🙏`;
    } else {
      text = `🕯️ *Yahrzeit Memorial Announcement - L'Zecher Olamim* 🕯️\n\n`;
      text += `We would like to inform you about the upcoming Yahrzeit of our beloved:\n`;
      text += `*${deceased.name}* - *${parentRelation}*\n\n`;
      text += `📅 *Hebrew Date:* ${hebrewDateStr}\n`;
      text += `📅 *Gregorian Date:* ${gregDate.toLocaleDateString('en-US')}\n`;
      if (parashaName) {
        text += `📖 *Shabbat Torah Portion:* ${parashaName}\n`;
      }
      if (daysRemaining === 0) {
        text += `📢 *The anniversary (Yahrzeit) is today!*\n`;
      } else if (daysRemaining === 1) {
        text += `📢 *The anniversary is tomorrow (1 day remaining)*\n`;
      } else {
        text += `📢 *${daysRemaining} days remaining until the anniversary (Yahrzeit)*\n`;
      }
      text += `\nIn loving memory, you are invited to view the memorial notice and light a candle:\n`;
      text += `🔗 ${shortUrl}\n\n`;
      text += `_May his/her memory be a blessing_ 🙏`;
    }

    openWhatsAppShare(text);
  };

  const bulletinTranslations = {
    he: {
      weeklyBulletin: "הפרשה והחגים השבוע בלוח",
      noHolidays: "אין חגים השבוע",
      shareWhatsApp: "שתף בוואטסאפ",
      parasha: "פרשת השבוע",
      holiday: "חג/אירוע השבוע",
      upcomingAliyah: "השבת הסמוכה (עליה לתורה):"
    },
    en: {
      weeklyBulletin: "This Week's Portion & Holidays",
      noHolidays: "No holidays this week",
      shareWhatsApp: "Share",
      parasha: "Torah Portion",
      holiday: "Holiday This Week",
      upcomingAliyah: "Preceding Shabbat (Aliyah):"
    },
    ru: {
      weeklyBulletin: "Глава Торы и Праздники этой недели",
      noHolidays: "Нет праздников на этой неделе",
      shareWhatsApp: "Поделиться",
      parasha: "Глава Торы",
      holiday: "Праздник на этой неделе",
      upcomingAliyah: "Ближайший Шаббат (Алия):"
    }
  };

  const bt = bulletinTranslations[lang];

  return (
    <div id="bulletin-board" className="bg-[#2d2312] border-2 border-[#c8a96e] rounded-xl p-6 mb-8 text-[#f0f4f8] shadow-2xl relative overflow-hidden font-sans">
      {/* Decorative background light */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#c8a96e]/10 blur-3xl pointer-events-none rounded-full"></div>
      
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-5 border-b border-[#c8a96e]/20 pb-4">
        <div className="flex items-center gap-3">
          <Bell className="w-6 h-6 text-[#c8a96e] animate-pulse" />
          <h2 className="text-xl md:text-2xl font-serif font-bold text-[#c8a96e] tracking-wide">
            {t.bulletinBoard}
          </h2>
        </div>

        {/* Global Weekly Parasha & Holiday Bulletin Banner */}
        {hebcalEvents.length > 0 && (
          <div className="bg-black/30 border border-[#c8a96e]/20 px-4 py-2.5 rounded-lg flex flex-col md:flex-row md:items-center gap-3 md:gap-6 text-xs max-w-xl">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#c8a96e]" />
              <div>
                <span className="text-gray-400 block text-[10px]">{bt.parasha}</span>
                <span className="font-bold text-white">
                  {currentParashaItem 
                    ? (lang === 'he' ? currentParashaItem.hebrew : currentParashaItem.title) 
                    : (lang === 'he' ? "טוען..." : "Loading...")}
                </span>
              </div>
            </div>

            {/* Shabbat times with interactive city picker */}
            <div className="flex items-center gap-2 border-t md:border-t-0 md:border-r border-[#c8a96e]/10 pt-2 md:pt-0 md:pr-4">
              <MapPin className="w-4 h-4 text-[#c8a96e] shrink-0" />
              <div>
                <span className="text-gray-400 block text-[10px]">
                  {lang === 'he' ? 'זמני שבת:' : lang === 'ru' ? 'Время Шаббата:' : 'Shabbat:'}
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <select
                    value={selectedCity.id}
                    onChange={(e) => {
                      const cid = Number(e.target.value);
                      const found = CITIES.find(c => c.id === cid);
                      if (found) {
                        setSelectedCity(found);
                        localStorage.setItem('shabbat_default_city_id', String(cid));
                      }
                    }}
                    className="bg-transparent border-none text-[#c8a96e] font-bold outline-none cursor-pointer text-xs p-0 pr-1 select-none"
                    style={{ direction: lang === 'he' ? 'rtl' : 'ltr' }}
                  >
                    {CITIES.map(c => (
                      <option key={c.id} value={c.id} className="bg-[#131a26] text-white">
                        {lang === 'he' ? c.nameHe : lang === 'ru' ? c.nameRu : c.nameEn}
                      </option>
                    ))}
                  </select>
                  <span className="text-gray-500 font-normal">|</span>
                  <span className="font-bold text-amber-400 font-mono text-xs flex items-center gap-0.5" title={lang === 'he' ? 'כניסת שבת (הדלקת נרות)' : 'Candle lighting'}>
                    🕯️ {shabbatCandles || '...'}
                  </span>
                  {shabbatHavdalah && (
                    <span className="text-indigo-400 font-mono text-xs flex items-center gap-0.5" title={lang === 'he' ? 'מוצאי שבת' : 'Havdalah'}>
                      ✨ {shabbatHavdalah}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {currentWeekHolidays.length > 0 && (
              <div className="flex items-center gap-2 border-t md:border-t-0 md:border-r border-[#c8a96e]/10 pt-2 md:pt-0 md:pr-4">
                <Calendar className="w-4 h-4 text-[#c8a96e]" />
                <div>
                  <span className="text-gray-400 block text-[10px]">{bt.holiday}</span>
                  <span className="font-bold text-amber-400">
                    {currentWeekHolidays.map(h => lang === 'he' ? h.hebrew : h.title).join(", ")}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {matchedEvents.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-6 text-center text-[#f0f4f8]/70">
          <span className="text-3xl mb-2">🕯️</span>
          <p className="text-base font-sans leading-relaxed max-w-md">
            {t.noMemorialsToday}
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Today's Memorials */}
          {todayList.length > 0 && (
            <div>
              <h3 className="text-sm font-sans uppercase tracking-wider text-[#c8a96e] mb-3 font-semibold flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                {t.todayMemorials}
              </h3>
              <div className="grid gap-3 grid-cols-1">
                {todayList.map((event, idx) => {
                  const m = event.deceased.month;
                  const normalized = normalizeMonthName(m);
                  let monthIdx = HEBREW_MONTHS_HE.indexOf(normalized);
                  if (monthIdx === -1) monthIdx = 0;
                  const monthStr = lang === 'he' ? HEBREW_MONTHS_HE[monthIdx] : lang === 'en' ? HEBREW_MONTHS_EN[monthIdx] : HEBREW_MONTHS_RU[monthIdx];
                  const dayStr = lang === 'he' ? gimatriya(event.deceased.day) : event.deceased.day.toString();
                  
                  const precedingShabbat = getPrecedingShabbatParasha(event.gregorianDate);
                  const parashaLabel = precedingShabbat 
                    ? (lang === 'he' ? precedingShabbat.hebrew : precedingShabbat.title)
                    : null;

                  return (
                    <div 
                      key={`today-${idx}`}
                      onClick={() => onSelectDeceased(event.deceased)}
                      className={`bg-[#131a26]/80 hover:bg-[#131a26] border rounded-lg p-4 cursor-pointer transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-4 group animate-yahrzeit-fire ${lang === 'he' ? 'text-right' : 'text-left'}`}
                      dir={lang === 'he' ? 'rtl' : 'ltr'}
                    >
                      <div className="flex items-start gap-4">
                        {event.deceased.image ? (
                          <img 
                            src={event.deceased.image} 
                            alt={event.deceased.name} 
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded-full object-cover border border-[#c8a96e]/40 group-hover:scale-105 transition-transform duration-300 shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-[#c8a96e]/15 flex items-center justify-center text-xl shadow-inner group-hover:scale-105 transition-transform duration-300 shrink-0">
                            🕯️
                          </div>
                        )}
                        <div className="space-y-1">
                          <p className="text-sm md:text-base font-sans font-medium text-[#ffffff]">
                            {formatHalachicAlert(event.deceased, dayStr, monthStr)}
                          </p>
                          {parashaLabel && (
                            <p className="text-xs text-[#c8a96e] font-sans flex items-center gap-1.5">
                              <BookOpen className="w-3.5 h-3.5 text-[#c8a96e]" />
                              <span>{bt.upcomingAliyah} <strong>{parashaLabel}</strong></span>
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2.5 self-end md:self-auto shrink-0">
                        {/* WhatsApp Invite Share Button */}
                        <button
                          type="button"
                          onClick={(e) => shareOnWhatsApp(event.deceased, event.gregorianDate, event.hebrewDateStr, parashaLabel, e)}
                          className="flex items-center gap-1.5 bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/30 hover:border-emerald-500 text-emerald-400 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer"
                          title={bt.shareWhatsApp}
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>{bt.shareWhatsApp}</span>
                        </button>

                        <span className="text-xs font-mono text-[#c8a96e] bg-[#c8a96e]/10 px-2.5 py-1.5 rounded border border-[#c8a96e]/20 group-hover:bg-[#c8a96e]/25 transition-all">
                          {lang === 'he' ? 'היום' : lang === 'ru' ? 'Сегодня' : 'Today'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Upcoming Memorials */}
          {upcomingList.length > 0 && (
            <div>
              <h3 className="text-sm font-sans uppercase tracking-wider text-[#c8a96e]/80 mb-3 font-semibold">
                {t.upcomingMemorials}
              </h3>
              <div className="grid gap-3 grid-cols-1">
                {upcomingList.map((event, idx) => {
                  const m = event.deceased.month;
                  const normalized = normalizeMonthName(m);
                  let monthIdx = HEBREW_MONTHS_HE.indexOf(normalized);
                  if (monthIdx === -1) monthIdx = 0;
                  const monthStr = lang === 'he' ? HEBREW_MONTHS_HE[monthIdx] : lang === 'en' ? HEBREW_MONTHS_EN[monthIdx] : HEBREW_MONTHS_RU[monthIdx];
                  const dayStr = lang === 'he' ? gimatriya(event.deceased.day) : event.deceased.day.toString();
                  
                  const precedingShabbat = getPrecedingShabbatParasha(event.gregorianDate);
                  const parashaLabel = precedingShabbat 
                    ? (lang === 'he' ? precedingShabbat.hebrew : precedingShabbat.title)
                    : null;

                  return (
                    <div 
                      key={`upcoming-${idx}`}
                      onClick={() => onSelectDeceased(event.deceased)}
                      className={`bg-[#131a26]/50 hover:bg-[#131a26] border rounded-lg p-4 cursor-pointer transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-4 group animate-yahrzeit-upcoming ${lang === 'he' ? 'text-right' : 'text-left'}`}
                      dir={lang === 'he' ? 'rtl' : 'ltr'}
                    >
                      <div className="flex items-start gap-4">
                        {event.deceased.image ? (
                          <img 
                            src={event.deceased.image} 
                            alt={event.deceased.name} 
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded-full object-cover border border-[#c8a96e]/20 group-hover:scale-105 transition-transform duration-300 shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-[#f0f4f8]/5 flex items-center justify-center text-xl shadow-inner group-hover:bg-[#c8a96e]/10 transition-all duration-300 shrink-0">
                            🕯️
                          </div>
                        )}
                        <div className="space-y-1">
                          <p className="text-sm md:text-base font-sans text-[#f0f4f8]/90">
                            {formatHalachicAlert(event.deceased, dayStr, monthStr)}
                          </p>
                          {parashaLabel && (
                            <p className="text-xs text-[#c8a96e]/90 font-sans flex items-center gap-1.5">
                              <BookOpen className="w-3.5 h-3.5 text-[#c8a96e]/70" />
                              <span>{bt.upcomingAliyah} <strong>{parashaLabel}</strong></span>
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2.5 self-end md:self-auto shrink-0">
                        {/* WhatsApp Invite Share Button */}
                        <button
                          type="button"
                          onClick={(e) => shareOnWhatsApp(event.deceased, event.gregorianDate, event.hebrewDateStr, parashaLabel, e)}
                          className="flex items-center gap-1.5 bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/30 hover:border-emerald-500 text-emerald-400 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer"
                          title={bt.shareWhatsApp}
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>{bt.shareWhatsApp}</span>
                        </button>

                        <span className="text-xs font-mono text-[#c8a96e]/80 bg-[#c8a96e]/5 px-2.5 py-1.5 rounded border border-[#c8a96e]/10 whitespace-nowrap">
                          {event.daysCount === 1 ? t.tomorrow : t.inNDays.replace('{n}', event.daysCount.toString())}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
